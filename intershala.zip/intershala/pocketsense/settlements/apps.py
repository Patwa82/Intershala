# settlements/apps.py

from django.apps import AppConfig

class SettlementsConfig(AppConfig):
    name = 'settlements'
